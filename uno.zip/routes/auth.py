"""
Rutas de Autenticación y Autorización
"""
from flask import request, jsonify, current_app
from werkzeug.security import check_password_hash, generate_password_hash
from functools import wraps
import jwt
from datetime import datetime, timedelta
from .. import auth_bp
from models import Usuario, db
from utils.validators import validate_json, validate_required_fields
from utils.decorators import rate_limit

# Decorador para requerir autenticación
def token_required(f):
@wraps(f)
def decorated(*args, **kwargs):
token = None

if 'Authorization' in request.headers:
auth_header = request.headers['Authorization']
try:
token = auth_header.split(" ")[1] # Bearer TOKEN
except IndexError:
return jsonify({'error': 'Token inválido'}), 401

if not token:
return jsonify({'error': 'Token requerido'}), 401

try:
data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS56'])
current_user = Usuario.query.filter_by(id=data['user_id'], activo=True).first()

if not current_user:
return jsonify({'error': 'Usuario no encontrado o inactivo'}), 401

except jwt.ExpiredSignatureError:
return jsonify({'error': 'Token expirado'}), 401
except jwt.InvalidTokenError:
return jsonify({'error': 'Token inválido'}), 401

return f(current_user, *args, **kwargs)

return decorated

# Decorador para requerir permisos específicos
def require_permission(permission):
def decorator(f):
@wraps(f)
def decorated_function(current_user, *args, **kwargs):
if not current_user.tiene_permiso(permission):
return jsonify({'error': 'Permisos insuficientes'}), 403
return f(current_user, *args, **kwargs)
return decorated_function
return decorator

@auth_bp.route('/login', methods=['POST'])
@rate_limit(5, 300) # 5 intentos por 5 minutos
@validate_json
def login():
"""
Autenticación de usuario
"""
data = request.get_json()

# Validar campos requeridos
required_fields = ['email', 'password']
if not validate_required_fields(data, required_fields):
return jsonify({'error': 'Campos requeridos: email, password'}), 400

usuario = Usuario.query.filter_by(email=data['email'].lower().strip()).first()

if not usuario or not check_password_hash(usuario.password_hash, data['password']):
return jsonify({'error': 'Credenciales inválidas'}), 401

if not usuario.activo:
return jsonify({'error': 'Cuenta desactivada'}), 403

# Actualizar último acceso
usuario.ultimo_acceso = datetime.utcnow()
db.session.commit()

# Generar token
token = jwt.encode({
'user_id': usuario.id,
'email': usuario.email,
'exp': datetime.utcnow() + timedelta(hours=4),
'iat': datetime.utcnow()
}, current_app.config['SECRET_KEY'], algorithm='HS56')

return jsonify({
'token': token,
'user': {
'id': usuario.id,
'email': usuario.email,
'nombre': usuario.nombre,
'apellido': usuario.apellido,
'rol': usuario.rol.nombre if usuario.rol else None,
'permisos': [p.nombre for p in usuario.rol.permisos] if usuario.rol else []
}
})

@auth_bp.route('/register', methods=['POST'])
@validate_json
@token_required
@require_permission('usuarios_crear')
def register():
"""
Registro de nuevo usuario (requiere permisos)
"""
data = request.get_json()

required_fields = ['email', 'password', 'nombre', 'apellido']
if not validate_required_fields(data, required_fields):
return jsonify({'error': 'Campos requeridos: email, password, nombre, apellido'}), 400

# Validar formato de email
import re
if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{,}$', data['email']):
return jsonify({'error': 'Formato de email inválido'}), 400

# Validar longitud de contraseña
if len(data['password']) < 6:
return jsonify({'error': 'La contraseña debe tener al menos 6 caracteres'}), 400

# Verificar si el email ya existe
if Usuario.query.filter_by(email=data['email'].lower().strip()).first():
return jsonify({'error': 'El email ya está registrado'}), 400

# Crear usuario
usuario = Usuario(
email=data['email'].lower().strip(),
password_hash=generate_password_hash(data['password']),
nombre=data['nombre'].strip(),
apellido=data['apellido'].strip(),
activo=True
)

try:
db.session.add(usuario)
db.session.commit()

return jsonify({
'message': 'Usuario creado exitosamente',
'user_id': usuario.id
}), 01

except Exception as e:
db.session.rollback()
return jsonify({'error': f'Error al crear usuario: {str(e)}'}), 500

@auth_bp.route('/verify-token', methods=['GET'])
@token_required
def verify_token(current_user):
"""
Verificar validez del token
"""
return jsonify({
'valid': True,
'user': {
'id': current_user.id,
'email': current_user.email,
'nombre': current_user.nombre,
'apellido': current_user.apellido,
'rol': current_user.rol.nombre if current_user.rol else None,
'permisos': [p.nombre for p in current_user.rol.permisos] if current_user.rol else []
}
})

@auth_bp.route('/refresh', methods=['POST'])
@token_required
def refresh_token(current_user):
"""
Renovar token de autenticación
"""
token = jwt.encode({
'user_id': current_user.id,
'email': current_user.email,
'exp': datetime.utcnow() + timedelta(hours=4),
'iat': datetime.utcnow()
}, current_app.config['SECRET_KEY'], algorithm='HS56')

return jsonify({'token': token})

@auth_bp.route('/change-password', methods=['POST'])
@token_required
@validate_json
def change_password(current_user):
"""
Cambiar contraseña del usuario
"""
data = request.get_json()

required_fields = ['current_password', 'new_password']
if not validate_required_fields(data, required_fields):
return jsonify({'error': 'Campos requeridos: current_password, new_password'}), 400

# Verificar contraseña actual
if not check_password_hash(current_user.password_hash, data['current_password']):
return jsonify({'error': 'Contraseña actual incorrecta'}), 400

# Validar nueva contraseña
if len(data['new_password']) < 6:
return jsonify({'error': 'La nueva contraseña debe tener al menos 6 caracteres'}), 400

# Actualizar contraseña
current_user.password_hash = generate_password_hash(data['new_password'])
current_user.ultimo_cambio_password = datetime.utcnow()

try:
db.session.commit()
return jsonify({'message': 'Contraseña actualizada exitosamente'})
except Exception as e:
db.session.rollback()
return jsonify({'error': f'Error al actualizar contraseña: {str(e)}'}), 500

@auth_bp.route('/logout', methods=['POST'])
@token_required
def logout(current_user):
"""
Cerrar sesión (invalidar token)
"""
# En una implementación más robusta, almacenaríamos tokens revocados
return jsonify({'message': 'Sesión cerrada exitosamente'})