from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean
from . import db
from models.base import BaseModelMixin

class Camara(BaseModelMixin, db.Model):
    __tablename__ = 'camaras'

    codigo = Column(String(50), unique=True, nullable=False, index=True)
    nombre = Column(String(100), nullable=False)
    modelo = Column(String(100), nullable=True)
    marca = Column(String(50), nullable=True)
    tipo_camara = Column(String(50), nullable=False, default='IP')
    estado = Column(String(20), nullable=False, default='activo')
    
    ip_address = Column(String(45), nullable=True)
    mac_address = Column(String(17), nullable=True)
    fecha_instalacion = Column(DateTime, default=datetime.utcnow)
    observaciones = Column(Text, nullable=True)

    @property
    def ip(self):
        """Compatibilidad con templates que usan camara.ip"""
        return self.ip_address

    def to_dict(self):
        """Serialización segura para APIs/debugging"""
        return {
            'id': self.id,
            'codigo': self.codigo,
            'nombre': self.nombre,
            'ip': self.ip,
            'estado': self.estado,
            'tipo_camara': self.tipo_camara,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

    def __repr__(self):
        return f"<Camara(id={self.id}, codigo='{self.codigo}', nombre='{self.nombre}')>"