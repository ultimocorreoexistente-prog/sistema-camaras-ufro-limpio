"""
Paquete de modelos para el Sistema de Cámaras UFRO
Permite: from models import db, Camara, Usuario, Gabinete, ...
"""

# Instancia única compartida de SQLAlchemy
from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()

# Enums compartidos (usados en gabinete.py y equipo.py)
import enum

class EquipmentStatus(enum.Enum):
    ACTIVO = "activo"
    INACTIVO = "inactivo"
    MANTENIMIENTO = "mantenimiento"
    BAJA = "baja"
    FALLA = "falla"

class EquipmentType(enum.Enum):  # ✅ AÑADIDO (faltaba)
    CAMARA = "camara"
    SWITCH = "switch"
    NVR = "nvr"
    UPS = "ups"
    GABINETE = "gabinete"
    FUENTE_PODER = "fuente_poder"
    MANTENIMIENTO = "mantenimiento"
    FALLA = "falla"

# Importar modelos (orden de dependencias respetado)
from .usuario import Usuario
from .ubicacion import Ubicacion
from .camara import Camara
from .gabinete import Gabinete, GabineteEquipment
from .switch import Switch
from .nvr import NVR
from .ups import UPS
from .fuente_poder import FuentePoder
from .falla import Falla
from .mantenimiento import Mantenimiento
from .fotografia import Fotografia
from .equipo_tecnico import EquipoTecnico

# Exportar para imports directos
__all__ = [
    'db',
    'EquipmentStatus',
    'EquipmentType',  # ✅ AÑADIDO
    'Usuario',
    'Ubicacion',
    'Camara',
    'Gabinete',
    'GabineteEquipment',
    'Switch',
    'NVR',
    'UPS',
    'FuentePoder',
    'Falla',
    'Mantenimiento',
    'Fotografia',
    'EquipoTecnico'
]

# Funciones de inicialización (retrocompatibles)
def init_models():
    """Retrocompatible con init_db.py antiguo"""
    return Usuario, Camara

def init_db(app):
    """Inicializar base de datos con app Flask"""
    db.init_app(app)
    with app.app_context():
        db.create_all()
        # Crear superadmin si no existe
        if not Usuario.query.filter_by(email='Charles.Jelvez@ufrontera.cl').first():
            from werkzeug.security import generate_password_hash
            import secrets
            admin = Usuario(
                username='charles.jelvez',
                email='Charles.Jelvez@ufrontera.cl',
                nombre='Charles Jelvez',
                rol='superadmin',
                activo=True
            )
            temp_pass = secrets.token_urlsafe(12)[:12]
            admin.password_hash = generate_password_hash(temp_pass)
            db.session.add(admin)
            db.session.commit()
            print(f"✅ Superadmin creado: Charles.Jelvez@ufrontera.cl / {temp_pass}")