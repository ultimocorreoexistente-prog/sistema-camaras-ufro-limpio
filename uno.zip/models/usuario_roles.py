class UserRole:
    SUPERADMIN = 'superadmin'
    ADMINISTRADOR = 'administrador'
    TECNICO = 'tecnico'
    OPERADOR = 'operador'
    VISUALIZADOR = 'visualizador'